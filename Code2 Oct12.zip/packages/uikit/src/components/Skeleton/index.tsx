export { default as Skeleton, SkeletonV2 } from "./Skeleton";
export type { SkeletonProps } from "./types";
