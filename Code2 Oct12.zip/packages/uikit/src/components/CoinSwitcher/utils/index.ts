export function importAll(r: any): string[] {
  return r.keys().map(r);
}
